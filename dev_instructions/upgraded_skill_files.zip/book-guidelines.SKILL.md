---
name: book-guidelines
description: Generates a structured "guidelines" markdown study-guide for a book, from a fixed sources/[book]/book.pdf input to a fixed vaults/[book]/book-guidelines.md output, and drafts a book-specific vaults/[book]/.learning-goals.md (Focus-Area-tagged) if one doesn't already exist. Manual invocation only — invoke explicitly with /book-guidelines, never automatically.
disable-model-invocation: true
argument-hint: "[book-folder-name]"
---

# Book Guidelines Generator

Turns a source book file into a single, richly structured Markdown "book-guidelines" document: a header, a nested ontological topic index, and a chapter-by-chapter breakdown with key definitions and study questions. It also drafts a starter book-specific `.learning-goals.md`, tagged against the workbench's fixed Focus Areas, so `book-topic-article` has something to work with on this book without the user hand-writing it first.

**Invocation:** this skill only runs when explicitly called with `/book-guidelines`. It must never be triggered automatically by Claude inferring intent from conversation — always wait for the explicit command.

This skill assumes (and enforces) a fixed project layout:

```
sources/[book]/book.pdf            <- input: the book always lives here, always named book.pdf
vaults/[book]/                     <- output: the generated guideline markdown goes here
vaults/.learning-goals.md          <- optional input: workbench-wide Focus Areas + learning goals
vaults/[book]/.learning-goals.md   <- output (only if absent): book-specific Focus-Area-tagged draft
```

`[book]` is a folder name, one per book (e.g. `sources/thompson-type-theory/book.pdf`).

## Workflow

### Step 1 — Resolve the book folder

1. Take `[book]` from `$ARGUMENTS`. If no argument was given, ask the user which folder under `sources/` to process (list the available ones as candidates) — do not guess.
2. The input file is always `sources/[book]/book.pdf`. Confirm it exists at that exact path.
3. If `sources/[book]/book.pdf` doesn't exist, check for a close match (typos, different casing on `[book]`) before telling the user it's missing. Never invent or fetch a book from the web to fill the gap, and never process a differently-named file in that folder without confirming with the user first — the convention is strictly `book.pdf`.

### Step 2 — Extract the content

The source is always a PDF. Extract its text. If the PDF is scanned/image-based, OCR may be required; flag this to the user if extraction yields little to no text rather than silently producing a thin guide.

For long books, don't try to hold the entire raw text in context at once if it's very large — read it chapter-by-chapter (using table-of-contents / heading markers to find chapter boundaries) rather than truncating silently. If the book has no clear chapter/section markup, infer reasonable divisions from the text (major headings, part breaks, numbered sections) and note that the chapter boundaries are inferred.

### Step 3 — Analyze

While reading, track for each chapter (or, for unstructured books, each major part):
- A one-paragraph summary of what the chapter covers and why it's there.
- Section-by-section (or subsection-by-subsection) important **definitions and concepts** — named terms, formal definitions, key distinctions the author draws. Prefer the author's own terminology; keep definitions concise (one line to a few lines each).
- 1–3 **key questions** per chapter that a critical reader should be able to answer after reading it — these should probe the chapter's central claims or trickiest distinctions, not trivia.

Also track, across the whole book:
- The book's title, author(s), and — if stated or inferable from the preface/intro — the author's own stated purpose/intent for writing it.
- Every named topic/subtopic in the book, so it can be organized into a nested outline (see template below). Group related subtopics under their parent topic; mirror the book's own part/chapter/section structure where it's sensible, but reorganize into a cleaner ontology where the book's structure is more historical/narrative than topical.

### Step 4 — Write the output file

Create the file at exactly:

```
vaults/[book]/book-guidelines.md
```

- The filename is always `book-guidelines.md` — no book title, no other variation. The book folder name (`[book]`) is what disambiguates one book's guide from another's, not the filename.
- Create the `vaults/[book]/` folder if it doesn't exist yet.

Use exactly this document structure:

```markdown
# <Book Title> — Guidelines

## Header

**Title:** ...
**Author(s):** ...
**Publication:** ...

**Brief Summary:**
[2-5 sentences: what the book covers and its central thesis/organizing idea]

**Intent of the Author:**
[1-3 sentences: why the author wrote it / what they want the reader to come away with]

---

## Topic List

1. **<Broad topic, phrased as a generalized category>**
   - <Subtopic, phrased as a plain, title-cased sentence/fragment — no punctuation>
   - <Subtopic>
2. **<Broad topic>**
   - <Subtopic>
   - ...

---

## Chapter Summaries

### Chapter N: <Chapter Title> (pp. X–Y)

**Summary:** [1-2 sentences]

**Key Definitions & Concepts by Section:**
- **N.1 <Section Name>** — term (definition), term (definition), ...
- **N.2 <Section Name>** — ...

**Key Questions:**
1. ...
2. ...

---
[repeat per chapter]
```

Notes on filling the template:
- The **Topic List** is a single unified ontology for the *whole book*, not one list per chapter — group by subject matter, not by chapter number. See **Topic List Style** below for exact formatting rules.
- The **Chapter Summaries** section is the one place that stays chapter-ordered, matching the book's own table of contents.
- Preserve important formal notation (symbols, formulas) exactly as the book uses it — don't paraphrase notation away. See **Mathematical Notation** below for how to format it. (This applies to Chapter Summaries; the Topic List itself stays in plain sentences per the style rules below — LaTeX there only if a symbol *is* the concept and can't be named in words, e.g. `$\lambda$-calculus`.)
- If a chapter has no natural subsections, just give a flat bullet list of definitions/concepts instead of the "by section" breakdown.
- Skip empty subsections rather than padding with "N/A".

**Topic List Style:**
- **Exactly two levels, no deeper.** Numbered top-level topics (`1.`, `2.`, ...), each a broad category in **bold**. Each gets a flat list of bulleted subtopics indented one level underneath — never a third level, never sub-bullets under a subtopic.
- **Top-level topics are generalized categories**, not chapter titles or section titles — the name a reader would search for if they wanted "everything about X" (e.g. "The Curry–Howard Isomorphism", "Sense and Denotation (Frege's Dichotomy)").
- **Subtopics are plain sentences or sentence fragments that name what the concept *is*, not what the book *says about* it.** Convert the source material's own longer, punctuation-heavy headings/claims into short, plain, title-cased phrases:
  - Strip trailing parentheticals, dates, colons, and semicolons that just add commentary or attribution: `Deductions as trees; hypotheses "alive" vs "dead" (discharged)` → `Deductions as trees`
  - Strip named attributions/dates that aren't essential to recognizing the concept: `Gentzen's theorem (1934): the cut rule is eliminable` → `Gentzen's theorem` (keep the named result if that's how the book/field refers to it, drop the year and the restated claim)
  - Collapse compound, multi-clause headings into one short descriptive sentence rather than preserving every clause: `Resolution: restricting cut to substitution instances of axioms; Horn clauses and PROLOG as disciplined cut` → `Resolution by restricting cuts to substitution instances of Horn clauses`
  - No colons, semicolons, or parenthetical asides inside a subtopic line. If the source heading has multiple ideas glued together with `;` or `:`, either merge them into one plain sentence (preferred) or split into two separate subtopic bullets if they're genuinely distinct concepts.
  - Keep proper nouns, named theorems, and essential mathematical notation (per the Mathematical Notation rules) — simplification means cutting *punctuation and restated claims*, not cutting the actual concept name.
- **Consistency matters more than exhaustiveness.** Every subtopic line should read the same way — a short, plain, declarative phrase — not a mix of full sentences, fragments, and notation-heavy strings. When in doubt, favor the shorter, more general phrasing.

**Mathematical Notation & LaTeX:**
- ALWAYS use standard LaTeX for mathematical notation — symbols, formulas, and named theorems alike.
- Use single dollar signs (`$...$`) for inline math and double dollar signs (`$$ ... $$`) on their own line for standalone/display equations.
- NEVER place LaTeX formulas or mathematical symbols inside code blocks or inline code spans (`` `...` ``). Backticks are reserved exclusively for executable or pseudo-code constructs (e.g. function names, code snippets) — not for math, even short symbols like a single variable.
  - Wrong: `` `A ⇒ B` `` or a fenced block containing `∀x. P(x)`
  - Right: `$A \Rightarrow B$` inline, or a `$$...$$` block for a standalone rule/derivation

### Step 5 — Draft a book-specific `.learning-goals.md` (only if one doesn't already exist)

This step is **additive and non-destructive**: it never touches an existing file, and it never invents a category system of its own.

1. Check whether `vaults/[book]/.learning-goals.md` already exists.
   - **If it exists:** skip this step entirely. Never overwrite or append to a user-authored learning-goals file — that file may already encode deliberate narrowing (per that file's own convention, e.g. "this book is mainly here for Part 3"). Note in Step 6 that it was left untouched.
2. Read `vaults/.learning-goals.md` (the workbench-wide file), if present, specifically its **Focus Areas** section — the fixed category set (name, slug, and short description per area) that the whole pipeline shares.
   - **If `vaults/.learning-goals.md` is missing, or has no Focus Areas section:** skip this step entirely and say so in Step 6 — there's no fixed category set to tag against, and inventing one here would fork the taxonomy `learning-roadmap` and `book-topic-article` both depend on. Do not fabricate Focus Areas.
3. Using the Topic List you just built in Step 4 (never the raw PDF text again — the Topic List is already the right level of abstraction), tag each **top-level topic** against every Focus Area it genuinely belongs to. Match semantically against each area's description and conceptual-connections list from the workbench file, not by keyword string-matching alone. A topic may carry more than one Focus Area tag; a topic that fits none of the areas well is simply left untagged (see the note below).
4. Write `vaults/[book]/.learning-goals.md` using this structure:

```markdown
# Learning Goals — <Book Title>

> Drafted automatically by `/book-guidelines` from this book's Topic List,
> tagged against the Focus Areas defined in `vaults/.learning-goals.md`.
> This is a starting point, not a final answer — edit freely to narrow
> emphasis, add a book-specific angle, or override a tag.

## Focus Areas covered by this book

### <Focus Area Name> (`<slug>`)
- <Top-level topic from the Topic List, verbatim>
- <Another matching top-level topic>

### <Next Focus Area Name> (`<slug>`)
- ...

## Untagged topics

<Only include this section if at least one top-level topic didn't fit any
Focus Area well. List them plainly — this is a signal for the user, not a
failure.>
- <Topic>
```

- List **every** Focus Area from the workbench file that has at least one matching topic in this book — omit an area entirely if nothing in the book maps to it, rather than padding it with a weak match.
- Under each area, list top-level topic names only (exactly as phrased in the Topic List just written), not subtopics — this file sets emphasis at the topic level; `book-topic-article` resolves the finer-grained connection when it writes the actual deep-dive.
- Keep this file short — it's a routing/emphasis aid, not a second Topic List. Don't restate subtopics, definitions, or page ranges here; those already live in `book-guidelines.md`.

### Step 6 — Confirm

After writing the file(s), briefly tell the user:
- where `book-guidelines.md` was saved, and flag anything notable from extraction (e.g. "chapter boundaries were inferred — the source PDF had no heading markup" or "pages 40-52 were image scans and may be under-represented");
- what happened with `.learning-goals.md`: drafted fresh (name the Focus Areas it was tagged against), left untouched because one already existed, or skipped because `vaults/.learning-goals.md` had no Focus Areas to draw from.

## Example

Input: `sources/thompson-type-theory/book.pdf`
Output: `vaults/thompson-type-theory/book-guidelines.md`

The output follows the template above: a Header naming Simon Thompson and summarizing the Curry-Howard framing, a two-level Topic List with broad numbered categories like "The Curry–Howard Isomorphism" or "Sense and Denotation (Frege's Dichotomy)" (rather than just "Chapter 4", "Chapter 5", "Chapter 7") and short plain-sentence subtopics underneath each, and nine Chapter Summaries each with per-section definitions and 2-3 key questions.

```markdown
## Topic List

1. **Sense and Denotation (Frege's Dichotomy)**
   - Sense vs. denotation
   - The Tarskian tradition
   - The Heyting tradition
2. **The Curry–Howard Isomorphism**
   - Simply typed $\lambda$-calculus
   - Denotational vs. operational significance of a type
```

Since `vaults/.learning-goals.md` exists and has a Focus Areas section, Step 5 also drafts `vaults/thompson-type-theory/.learning-goals.md`, tagging "The Curry–Howard Isomorphism" under `type-theory` (and, if the chapter also covers proof-term assignment as a proof-search procedure, under `automated-reasoning` too), and "Sense and Denotation" is left untagged if it's purely historical/philosophical framing with no clear mechanism payoff.
